import {Component,OnInit} from 'angular2/core';
declare var $:any;
@Component({
    selector: "cd-com",
    templateUrl: "app/candidate/candidate.component.html"
})

export class candidateData implements OnInit{
     ngOnInit(){
        
    } 
a:number=0;
b:number=0;
value=0;
add():void{
    this.value=(parseInt(this.a)+parseInt(this.b);
}
sub():void{
    this.value=(parseInt(this.a)-parseInt(this.b);
}
div():void{
    this.value=(parseInt(this.a)/parseInt(this.b);
}
mult():void{
    this.value=(parseInt(this.a)*parseInt(this.b);
}

candidateName:string= "";
candidateId:number=0;
candidateAge:number=0;
candidateCompany:string="";

candidateq(i):void{
    $.get('app/candidate/'+i+'.json',(d,r:any)=>{
        this.candidateName=d.candidateName;
        this.candidateId=d.candidateid;
        this.candidateAge=d.candidateAge;
        this.candidateCompany=d.candidateCompany;
    })
}
}

