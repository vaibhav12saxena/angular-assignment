import {Component} from 'angular2/core';
import {candidateData} from './candidate/candidate.component'


@Component({
    selector: "cd-app",
    template: "<cd-com>",
    directives: [candidateData]
})

export class AppComponent{
    
}
