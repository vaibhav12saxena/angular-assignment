import {Component} from 'angular2/core';
import {HomeComponent} from  './homePage/home.component';
import {HomeService} from './Homepage/home.service';
import {HTTP_PROVIDERS} from 'angular2/http';
import 'rxjs/Rx';

@Component({
    selector: 'lg-app',
    template: `<home>`,
  directives:[HomeComponent],
   providers: [HomeService,HTTP_PROVIDERS]
})

export class AppComponent{
    
}



