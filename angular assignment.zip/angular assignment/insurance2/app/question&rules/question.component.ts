import {Component,OnInit} from "angular2/core"
import {HomeService} from '../Homepage/home.service';

@Component({
      selector: 'question',
    templateUrl: `../app/question&rules/question.html`,
     providers: [HomeService]
})

export class RuleComponent implements OnInit{
    i:number=1;
constructor(private _productService:HomeService){
   }
     ngOnInit():void
    {
    this._productService.getProducts(`app/data/${this.i}.json`).subscribe(data=>{this.info=data
    this.rule1=this.info[0].id});
}  
}