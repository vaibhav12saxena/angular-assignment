import {Component,OnInit} from "angular2/core"
import {HomeService} from '../Homepage/home.service';

@Component({
      selector: 'rules',
    templateUrl: `../app/question&rules/rules.html`,
     providers: [HomeService]
})

export class RuleComponent implements OnInit{
    info:any[];
    rule1:string;
   constructor(private _productService:HomeService){
   }
  
     ngOnInit():void
    {
    this._productService.getProducts('app/data/rules.json').subscribe(data=>{this.info=data
    this.rule1=this.info[0].id});
}  
check:number=0;
tick:boolean;
Next(){
    if (this.tick==true) {
          this.check=1;
          alert("you have agreed to terms and condition");
    }
    else{
        alert("Kindly tick the checkbox");
    }
}   
}