import {Component,OnInit} from "angular2/core"
import {HomeService} from './home.service';
import {RuleComponent} from '../question&rules/rule.component'


@Component({
    selector: 'home',
    templateUrl: `../app/Homepage/home.html`,
    providers: [HomeService],
    directives: [RuleComponent]
})



export class HomeComponent implements OnInit{
   password:string;
   userId:string;
   info:any;
   insu:string="user";
  temp:number=0;
   logIn()
   {
      alert (this.userId+" "+this.password);
      for (var i=0;i<3;i++){
      if (this.userId==this.info[i].user1 && this.password==this.info[i].password){
           
          this.temp=1;
        }
    }
      ;

   }
   openNav() 
   {
      document.getElementById("mySidenav").style.width = "250px";
 }
   closeNav() 
    {
document.getElementById("mySidenav").style.width = "0";
    }
   constructor(private _productService:HomeService){

   }
  
    ngOnInit():void
    {
    this._productService.getProducts('app/data/user.json').subscribe(data=>this.info=data);
    console.log(this.info);
    
}   
    }






