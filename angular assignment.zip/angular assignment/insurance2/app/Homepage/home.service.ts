import {Injectable} from 'angular2/core';
import {Http,Response} from "angular2/http";
import {Observable} from "rxjs/Observable";

@Injectable()    //used to inject service..without this we cannot  use it

export class HomeService 
{
        
       constructor(private _http:Http){ }
       getProducts(x:string):Observable<any[]>
       {
                  return this._http.get(x).map((response:Response)=><any[]>response.json());
       } 
}









    
