import { Component, OnInit } from '@angular/core';
import {QuizService} from 'src/app/quiz.service'

@Component({
  selector: 'app-rules',
  templateUrl: '././rules.component.html',
  styleUrls: ['./rules.component.css']
})

export class RulesComponent implements OnInit {

 constructor(private _productService:QuizService) { }
  info:any;
  userId:string;
  pass:string;
  temp:number=0;
  rule1:string;
   rule2:string;
    rule3:string;
     rule4:string;
  ngOnInit() {
     this._productService.getProducts('data/rules.json').subscribe(data=>{this.info=data
      //for(var i=0;i<3;i++){
      this.rule1= this.info[0].rule;
      this.rule2= this.info[1].rule
      this.rule3= this.info[2].rule
      this.rule4= this.info[3].rule
       
    })}

check:number=0;
tick:boolean;
Next(){
    if (this.tick==true) {
          this.check=1;
          alert("you have agreed to terms and condition");
    }
    else{
        alert("Kindly tick the checkbox");
    }
}   

}

  

