import { Component, OnInit } from '@angular/core';
import {QuizService} from 'src/app/quiz.service'
@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

 constructor(private _productService:QuizService) { }
  info:any;
  q:string;
  temp:string;
  o1:string[];
  answer=[];
  so:string;
  buttons:string[]=["ques1","ques2","ques3","ques4","ques5","ques6"]
  count= parseInt(this.temp);
  ngOnInit() {
     this._productService.getProducts('data/ques1.json').subscribe(data=>{this.info=data
      this.q= this.info[0].q1;
      this.o1= this.info[0].o1;
    })
  }

selected(s:string){
  alert("You have selected "+s+" as your answer")
  console.log(s);
  console.log(this.count);
  this.answer.push(s);
  console.log(this.so);
}
Next1(x){
   this._productService.getProducts(`data/${x}.json`).subscribe(data=>{this.info=data
      this.q= this.info[0].q1;
      this.o1= this.info[0].o1;
      console.log(x);
      this.temp=x.charAt[5];
      console.log(this.answer)
 })}
}

