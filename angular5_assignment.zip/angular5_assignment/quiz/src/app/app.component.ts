import { Component } from '@angular/core';
import {QuizComponent} from  './quiz/quiz.component';
//import {HomeService} from './Homepage/home.service';
//import {HTTP_PROVIDERS} from 'angular2/http';
//import 'rxjs/Rx';


@Component({
  selector: 'app-root',
  template:'<router-outlet></router-outlet>' ,
  styleUrls: ['./app.component.css'],
     //providers: [HomeService,HTTP_PROVIDERS]
})
export class AppComponent {
  title = 'quiz';
}








