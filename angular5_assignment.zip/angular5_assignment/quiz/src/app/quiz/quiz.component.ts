import { Component, OnInit } from '@angular/core';
import {QuizService} from 'src/app/quiz.service';
import {RulesComponent} from 'src/app/rules/rules/rules.component'
@Component({
  selector: 'quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  constructor(private _productService:QuizService) { }
  info:any;
  userId:string;
  pass:string;
  temp:number=0;
    ngOnInit() {
     this._productService.getProducts('data/user.json').subscribe(data=>{this.info=data
    });
  }
logIn(){
  if (this.userId== this.info[0].user1 && this.pass==this.info[0].password){
    alert("Login succesful");
    this.temp=1;
    alert(this.temp)
  }
  else{
    alert("Incorrect userid password")
  }
}

}
