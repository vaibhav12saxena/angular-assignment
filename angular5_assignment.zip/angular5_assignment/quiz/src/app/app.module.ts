import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { QuizComponent } from './quiz/quiz.component';
import {HttpClientModule} from '@angular/common/http'
import {FormsModule} from '@angular/forms';
import { RulesComponent } from './rules/rules/rules.component';
import { QuestionComponent } from './question/question.component';
import { ApproutingModule } from './/approuting.module'
@NgModule({
  declarations: [
    AppComponent,
    QuizComponent,
    RulesComponent,
    QuestionComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ApproutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
